<?php
// Saglabā spēlētāja progresu failā data/saves/<hash>.json
require __DIR__ . '/config.php';
session_start();

$input = json_decode(file_get_contents('php://input'), true);
if (!is_array($input)) {
    respond(['ok' => false, 'error' => 'Nederīgi dati'], 400);
}

$name  = clean_name($input['name'] ?? '');
$state = clean_state($input['state'] ?? null);
if ($name === '' || $state === null) {
    respond(['ok' => false, 'error' => 'Trūkst vārda vai spēles datu'], 400);
}

$_SESSION['player'] = $name; // sesija atceras spēlētāju

$record = [
    'name'    => $name,
    'state'   => $state,
    'updated' => date('c'),
];

// LOCK_EX neļauj diviem pieprasījumiem vienlaikus bojāt failu
$ok = file_put_contents(save_path($name), json_encode($record, JSON_UNESCAPED_UNICODE), LOCK_EX);
respond(['ok' => $ok !== false]);
