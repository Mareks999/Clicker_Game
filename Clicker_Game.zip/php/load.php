<?php
// Ielādē spēlētāja progresu. Ja vārds nav norādīts, izmanto sesijā saglabāto.
require __DIR__ . '/config.php';
session_start();

$name = clean_name($_GET['name'] ?? ($_SESSION['player'] ?? ''));
if ($name === '') {
    respond(['ok' => false, 'error' => 'Nav norādīts vārds'], 400);
}
$_SESSION['player'] = $name;

$path = save_path($name);
if (!is_file($path)) {
    respond(['ok' => true, 'state' => null]); // jauns spēlētājs
}

$record = json_decode(file_get_contents($path), true);
respond(['ok' => true, 'state' => clean_state($record['state'] ?? null)]);
