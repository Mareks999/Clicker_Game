<?php
// Atgriež top 10 spēlētājus pēc kopā nopelnītajiem punktiem
require __DIR__ . '/config.php';

$rows = [];
foreach (glob(SAVE_DIR . '*.json') ?: [] as $file) {
    $rec = json_decode(file_get_contents($file), true);
    if (!isset($rec['name'], $rec['state']['totalEarned'])) continue;
    $rows[] = ['name' => $rec['name'], 'total' => (int)$rec['state']['totalEarned']];
}
usort($rows, fn($a, $b) => $b['total'] <=> $a['total']);
respond(['ok' => true, 'top' => array_slice($rows, 0, 10)]);
