<?php
// Kopīgas funkcijas visiem PHP failiem

const SAVE_DIR = __DIR__ . '/../data/saves/';
const UPGRADE_KEYS = ['power', 'auto', 'speed', 'mult', 'crit', 'bonus'];

// Atbild ar JSON un pārtrauc skriptu
function respond(array $data, int $code = 200): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

// Notīra spēlētāja vārdu (max 20 simboli, tikai burti, cipari, atstarpes, _ un -)
function clean_name($name): string
{
    $name = trim((string)$name);
    $name = preg_replace('/[^\p{L}\p{N} _-]/u', '', $name);
    return mb_substr($name, 0, 20);
}

// Faila ceļš konkrētam spēlētājam (vārds tiek pārvērsts par hash, lai nav bīstamu simbolu)
function save_path(string $name): string
{
    return SAVE_DIR . sha1(mb_strtolower($name)) . '.json';
}

// Pārbauda un notīra spēles stāvokli, ko atsūtījis pārlūks
function clean_state($state): ?array
{
    if (!is_array($state)) return null;

    $clean = [
        'points'      => max(0, (int)($state['points'] ?? 0)),
        'totalEarned' => max(0, (int)($state['totalEarned'] ?? 0)),
        'levels'      => [],
    ];
    foreach (UPGRADE_KEYS as $key) {
        $clean['levels'][$key] = max(0, min(1000, (int)($state['levels'][$key] ?? 0)));
    }
    return $clean;
}
