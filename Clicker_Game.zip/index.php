<?php
session_start();
// Sesija atceras pēdējo spēlētāju, lai pēc lapas pārlādes nav jāievada vārds no jauna
$player = $_SESSION['player'] ?? '';
?>
<!DOCTYPE html>
<html lang="lv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Truck Clicker</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/settings.css">
    <link rel="stylesheet" href="css/upgrades.css">
</head>
<body>
<div class="layout">

    <main class="game">
        <header class="topbar">
            <h1>🚚 Truck Clicker</h1>
            <div class="buttons">
                <button id="bonusButton" class="bonus-btn" disabled>🌙 Nakts maiņa</button>
                <button id="leaderboardButton">🏆 Līderi</button>
                <button id="settingsButton">⚙️</button>
            </div>
        </header>

        <div class="score-panel">
            <div class="score-label">Nopelnīts</div>
            <div class="score">€<span id="score">0</span></div>
            <div class="stats" id="stats"></div>
        </div>

        <div class="stage-info">
            <span id="stageName"></span>
            <div class="progress"><div id="progressBar"></div></div>
            <small id="progressText"></small>
        </div>

        <div id="stage">
            <div id="truckWrap" class="stage-0">
                <span id="badge">🚚</span>
                <input type="image" src="assets/images/truck.png" name="truck" id="truck" alt="Kravas auto">
            </div>
        </div>
        <small id="status"></small>
    </main>

    <aside class="shop">
        <h2>🏢 Uzņēmuma flote</h2>
        <div id="fleetList"></div>
        <h2>🔧 Uzlabojumi</h2>
        <div id="upgradesList"></div>
    </aside>

</div>

<div id="settingsMenu" class="settings-menu">
    <div class="settings-box">
        <h2>Iestatījumi</h2>
        <label>Skaļums <input type="range" id="volume" min="0" max="1" step="0.05" value="0.6"></label>
        <label><input type="checkbox" id="mute"> Izslēgt skaņu</label>
        <button id="changePlayer">Mainīt spēlētāju</button>
        <button id="resetButton">Atiestatīt spēli</button>
        <button id="closeSettings">Aizvērt</button>
    </div>
</div>

<div id="leaderboardMenu" class="settings-menu">
    <div class="settings-box">
        <h2>Top 10</h2>
        <ol id="leaderboardList"></ol>
        <button id="closeLeaderboard">Aizvērt</button>
    </div>
</div>

<div id="nameScreen" class="settings-menu">
    <div class="settings-box">
        <h2>Kā tevi sauc?</h2>
        <input type="text" id="nameInput" maxlength="20" placeholder="Spēlētāja vārds">
        <button id="startButton">Spēlēt</button>
    </div>
</div>

<div id="banner"></div>

<script>window.PLAYER = <?= json_encode($player, JSON_UNESCAPED_UNICODE) ?>;</script>
<script src="js/game.js"></script>
</body>
</html>
