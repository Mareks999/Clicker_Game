"use strict";

// ---- Uzlabojumi (tieši 5, kā prasīts uzdevumā) ----
const UPGRADES = {
  power: { name: "Jaudīgāks dzinējs", desc: "+2 € par katru klikšķi",         base: 15,  growth: 1.5, max: 100 },
  speed: { name: "Ātrāki reisi",      desc: "Papildu šoferis atgriežas ātrāk", base: 100, growth: 1.6, max: 20 },
  mult:  { name: "Izdevīgi līgumi",   desc: "+25% visiem ieņēmumiem",          base: 400, growth: 2.0, max: 15 },
  auto:  { name: "Papildu šoferis",   desc: "+3 € katrā reisā bez klikšķa",    base: 60,  growth: 1.6, max: 100 },
  bonus: { name: "Nakts maiņa",       desc: "Uz laiku dubulti ieņēmumi",       base: 300, growth: 2.0, max: 10 },
};

// Auto izskats mainās pēc kopā nopelnītās naudas (7 transformācijas)
const STAGES = [
  { at: 0,      name: "Vecais rūsganis" },
  { at: 50,     name: "Nomazgāts un spodrs" },
  { at: 200,    name: "Hromēts lielceļu zvērs" },
  { at: 800,    name: "Jauns dzinējs zem pārsega" },
  { at: 3000,   name: "Tālbraucēja lepnums" },
  { at: 10000,  name: "Turbo fūrmanis" },
  { at: 30000,  name: "Šosejas leģenda" },
  { at: 100000, name: "Nr. 1 visā autoparkā" },
];

const AUTOSAVE_MS = 10000;

// ---- Stāvoklis ----
let state = { points: 0, totalEarned: 0, levels: { power: 0, speed: 0, mult: 0, auto: 0, bonus: 0 } };
let playerName = "";
let stageIndex = 0;
let bonusEndsAt = 0, bonusReadyAt = 0;
let autoTimer = null;
let volume = parseFloat(localStorage.getItem("volume") ?? "0.6");
let muted = localStorage.getItem("muted") === "1";

const $ = id => document.getElementById(id);
const L = key => state.levels[key];

// ---- Skaņa (5 efekti) ----
const audio = {};
["click", "upgrade", "bonus", "transform", "deny"].forEach(k => audio[k] = new Audio("assets/sounds/" + k + ".wav"));
function play(name, rate = 1) {
  if (muted) return;
  const a = audio[name].cloneNode();
  a.volume = volume; a.playbackRate = rate;
  a.play().catch(() => {});
}

// ---- Aprēķini ----
const multiplier  = () => 1 + 0.25 * L("mult");
const bonusActive = () => Date.now() < bonusEndsAt;
const bonusFactor = () => bonusActive() ? 2 : 1;
const clickValue  = () => (1 + 2 * L("power")) * multiplier() * bonusFactor();
const autoValue   = () => 3 * L("auto") * multiplier() * bonusFactor();
const autoInterval = () => Math.max(200, Math.round(1000 * Math.pow(0.9, L("speed"))));
const bonusMs     = () => (10 + 5 * (L("bonus") - 1)) * 1000;
const cost        = key => Math.ceil(UPGRADES[key].base * Math.pow(UPGRADES[key].growth, L(key)));

function fmt(n) {
  n = Math.floor(n);
  if (n < 10000) return n.toLocaleString("lv-LV");
  const units = ["", "K", "M", "B"];
  let i = 0;
  while (n >= 1000 && i < units.length - 1) { n /= 1000; i++; }
  return n.toFixed(n < 100 ? 1 : 0) + units[i];
}

// ---- Punkti un transformācijas ----
function addPoints(amount) {
  state.points += amount;
  state.totalEarned += amount;
  const idx = STAGES.reduce((best, s, i) => state.totalEarned >= s.at ? i : best, 0);
  if (idx !== stageIndex) { stageIndex = idx; applyStage(idx, true); }
  updateUI();
}

function applyStage(idx, announce) {
  $("truckWrap").className = "stage-" + idx;
  $("badge").textContent = idx + 1;
  $("stageName").textContent = STAGES[idx].name;
  if (announce) {
    play("transform");
    banner("Transformācija: " + STAGES[idx].name);
    $("truckWrap").classList.add("flash");
    setTimeout(() => $("truckWrap").classList.remove("flash"), 900);
  }
}

function banner(text) {
  const b = $("banner");
  b.textContent = text;
  b.classList.add("show");
  clearTimeout(banner.t);
  banner.t = setTimeout(() => b.classList.remove("show"), 2500);
}

function floatText(text, x, y) {
  const el = document.createElement("div");
  el.className = "floater";
  el.textContent = text;
  el.style.left = x + "px"; el.style.top = y + "px";
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 900);
}

// ---- Klikšķis un automātiskie punkti ----
$("truck").addEventListener("click", e => {
  const gain = Math.max(1, Math.round(clickValue()));
  addPoints(gain);
  play("click");
  floatText("+" + fmt(gain), e.clientX, e.clientY);
});

function restartAuto() {
  clearInterval(autoTimer);
  autoTimer = setInterval(() => { if (L("auto") > 0) addPoints(Math.round(autoValue())); }, autoInterval());
}

// ---- Laika bonuss ----
$("bonusButton").addEventListener("click", () => {
  const now = Date.now();
  if (L("bonus") < 1 || bonusActive() || now < bonusReadyAt) return;
  bonusEndsAt = now + bonusMs();
  bonusReadyAt = bonusEndsAt + 30000;
  play("bonus");
  banner("Dubultie punkti aktivizēti!");
});

setInterval(() => {
  document.body.classList.toggle("bonus-on", bonusActive());
  const b = $("bonusButton"), now = Date.now();
  if (L("bonus") < 1) { b.disabled = true; b.textContent = "Nakts maiņa (nopērc uzlabojumu)"; }
  else if (bonusActive()) { b.disabled = true; b.textContent = "x2 vēl " + Math.ceil((bonusEndsAt - now) / 1000) + " s"; }
  else if (now < bonusReadyAt) { b.disabled = true; b.textContent = "Gaidi " + Math.ceil((bonusReadyAt - now) / 1000) + " s"; }
  else { b.disabled = false; b.textContent = "Nakts maiņa (" + bonusMs() / 1000 + " s)"; }
}, 250);

// ---- Veikals ----
function buildShop() {
  const list = $("upgradesList");
  list.innerHTML = "";
  Object.keys(UPGRADES).forEach((key, i) => {
    const u = UPGRADES[key];
    const row = document.createElement("div");
    row.className = "upgrade";
    row.id = "up-" + key;
    row.innerHTML =
      '<span class="no">' + (i + 1) + '</span>' +
      '<div class="up-info"><b>' + u.name + ' <span class="lvl"></span></b><small>' + u.desc + '</small></div>' +
      '<button class="buy"></button>';
    row.querySelector(".buy").onclick = () => buy(key);
    list.appendChild(row);
  });
}

function buy(key) {
  const price = cost(key);
  if (L(key) >= UPGRADES[key].max) return;
  if (state.points < price) { play("deny"); return; }
  state.points -= price;
  state.levels[key]++;
  play("upgrade");
  if (key === "speed") restartAuto();
  updateUI();
}

function updateUI() {
  $("score").textContent = fmt(state.points);
  $("stats").textContent = "Klikšķis: €" + fmt(clickValue()) + (L("auto") ? " · Auto: €" + fmt(autoValue()) + " / " + (autoInterval() / 1000).toFixed(2) + " s" : "");

  const next = STAGES[stageIndex + 1];
  $("progressBar").style.width = (next ? Math.min(100, (state.totalEarned - STAGES[stageIndex].at) / (next.at - STAGES[stageIndex].at) * 100) : 100) + "%";
  $("progressText").textContent = next ? fmt(state.totalEarned) + " / " + fmt(next.at) : "Maksimums!";

  Object.keys(UPGRADES).forEach(key => {
    const row = $("up-" + key), price = cost(key), btn = row.querySelector(".buy");
    row.querySelector(".lvl").textContent = "(lvl " + L(key) + ")";
    if (L(key) >= UPGRADES[key].max) { btn.textContent = "MAX"; btn.disabled = true; }
    else { btn.textContent = "€" + fmt(price); btn.disabled = false; row.classList.toggle("poor", state.points < price); }
  });
}

// ---- Saglabāšana (PHP) ----
function payload() { return JSON.stringify({ name: playerName, state }); }

async function saveGame() {
  if (!playerName) return;
  try {
    const res = await fetch("php/save.php", { method: "POST", headers: { "Content-Type": "application/json" }, body: payload() });
    const data = await res.json();
    $("status").textContent = data.ok ? "Saglabāts " + new Date().toLocaleTimeString("lv-LV") : "Neizdevās saglabāt";
  } catch { $("status").textContent = "Nav savienojuma ar serveri"; }
}
window.addEventListener("pagehide", () => { if (playerName) navigator.sendBeacon("php/save.php", new Blob([payload()], { type: "application/json" })); });

async function loadGame() {
  state = { points: 0, totalEarned: 0, levels: { power: 0, speed: 0, mult: 0, auto: 0, bonus: 0 } };
  try {
    const res = await fetch("php/load.php?name=" + encodeURIComponent(playerName));
    const data = await res.json();
    if (data.ok && data.state) state = data.state;
  } catch { $("status").textContent = "Nevar ielādēt saglabājumu"; }
  bonusEndsAt = bonusReadyAt = 0;
  stageIndex = STAGES.reduce((best, s, i) => state.totalEarned >= s.at ? i : best, 0);
  applyStage(stageIndex, false);
  restartAuto();
  updateUI();
}

// ---- Iestatījumi un starta ekrāns ----
$("volume").value = volume;
$("mute").checked = muted;
$("volume").oninput = e => { volume = parseFloat(e.target.value); localStorage.setItem("volume", volume); };
$("mute").onchange = e => { muted = e.target.checked; localStorage.setItem("muted", muted ? "1" : "0"); };

$("settingsButton").onclick = () => $("settingsMenu").style.display = "flex";
$("closeSettings").onclick = () => $("settingsMenu").style.display = "none";
$("saveButton").onclick = saveGame;

$("resetButton").onclick = () => {
  if (!confirm("Vai tiešām sākt no jauna?")) return;
  state = { points: 0, totalEarned: 0, levels: { power: 0, speed: 0, mult: 0, auto: 0, bonus: 0 } };
  bonusEndsAt = bonusReadyAt = 0;
  stageIndex = 0;
  applyStage(0, false);
  restartAuto();
  updateUI();
  saveGame();
  $("settingsMenu").style.display = "none";
};

$("changePlayer").onclick = async () => {
  await saveGame();
  $("settingsMenu").style.display = "none";
  $("nameInput").value = "";
  $("nameScreen").style.display = "flex";
};

async function startAs(name) {
  name = name.trim().slice(0, 20);
  if (!name) return;
  playerName = name;
  localStorage.setItem("player", name);
  $("nameScreen").style.display = "none";
  await loadGame();
}
$("startButton").onclick = () => startAs($("nameInput").value);
$("nameInput").onkeydown = e => { if (e.key === "Enter") startAs($("nameInput").value); };

// ---- Sākums ----
buildShop();
updateUI();
setInterval(saveGame, AUTOSAVE_MS);

const known = window.PLAYER || localStorage.getItem("player");
if (known) startAs(known); else $("nameScreen").style.display = "flex";
