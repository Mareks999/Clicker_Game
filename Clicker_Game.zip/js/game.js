"use strict";

/* =========================================================
   1. KONFIGURĀCIJA
   ========================================================= */

// Uzlabojumi: base = sākuma cena, growth = cenas pieauguma koeficients
const UPGRADES = {
    power: { name: "Spēks",               icon: "💪", desc: "+1 punkts par katru klikšķi",              base: 15,  growth: 1.5, max: 999 },
    auto:  { name: "Automātiskie punkti", icon: "🤖", desc: "+1 punkts katrā automātiskajā ciklā",      base: 50,  growth: 1.6, max: 999 },
    speed: { name: "Ātrums",              icon: "⚡", desc: "Automātiskais cikls par 10% ātrāks",       base: 100, growth: 1.8, max: 15 },
    mult:  { name: "Punktu reizinātājs",  icon: "✖️", desc: "+25% pie visiem iegūtajiem punktiem",      base: 500, growth: 2.2, max: 10 },
    crit:  { name: "Kritiskais klikšķis", icon: "🎯", desc: "+5% iespēja saņemt x5 punktus par klikšķi", base: 200, growth: 1.9, max: 10 },
    bonus: { name: "Laika bonuss",        icon: "⏱️", desc: "Atslēdz dubultos punktus (10 s, +5 s par līmeni)", base: 300, growth: 2.0, max: 8 },
};

// Kravas auto transformācijas (atkarībā no kopā nopelnītajiem punktiem)
const STAGES = [
    { at: 0,       name: "Vecais darbarūķis",   badge: "🚚" },
    { at: 100,     name: "Zaļais pārvadātājs",  badge: "🌿" },
    { at: 500,     name: "Zilais ātrgaitnieks", badge: "💨" },
    { at: 2000,    name: "Oranžais milzis",     badge: "🔶" },
    { at: 8000,    name: "Nakts braucējs",      badge: "🌙" },
    { at: 30000,   name: "Uguns kravas auto",   badge: "🔥" },
    { at: 100000,  name: "Varavīksnes zvērs",   badge: "🌈" },
    { at: 400000,  name: "Kosmosa kravinieks",  badge: "🚀" },
    { at: 1000000, name: "Zelta leģenda",       badge: "👑" },
];

const BONUS_COOLDOWN = 45000;   // ms pēc bonusa beigām
const AUTOSAVE_MS = 10000;      // automātiskā saglabāšana ik pēc 10 s

const SOUND_FILES = {
    click:     "assets/sounds/click.wav",
    upgrade:   "assets/sounds/upgrade.wav",
    bonus:     "assets/sounds/bonus.wav",
    transform: "assets/sounds/transform.wav",
    final:     "assets/sounds/final.wav",
    deny:      "assets/sounds/deny.wav",
};

/* =========================================================
   2. STĀVOKLIS
   ========================================================= */

function newState() {
    return {
        points: 0,
        totalEarned: 0,
        levels: { power: 0, auto: 0, speed: 0, mult: 0, crit: 0, bonus: 0 },
    };
}

let state = newState();
let playerName = "";
let stageIndex = 0;
let bonusEndsAt = 0;
let bonusReadyAt = 0;
let autoTimer = null;

/* =========================================================
   3. DOM ELEMENTI
   ========================================================= */

const $ = (id) => document.getElementById(id);

const truck = $("truck");
const truckWrap = $("truckWrap");
const scoreEl = $("score");
const statsEl = $("stats");
const bonusButton = $("bonusButton");

/* =========================================================
   4. SKAŅA
   ========================================================= */

const sounds = {};
for (const key in SOUND_FILES) {
    sounds[key] = new Audio(SOUND_FILES[key]);
}

let volume = parseFloat(localStorage.getItem("volume") ?? "0.6");
let muted = localStorage.getItem("muted") === "1";

function play(name, rate = 1) {
    if (muted) return;
    const a = sounds[name].cloneNode(); // klons ļauj skaņai atskanēt vairākas reizes pēc kārtas
    a.volume = volume;
    a.playbackRate = rate;
    a.play().catch(() => {});
}

/* =========================================================
   5. APRĒĶINI
   ========================================================= */

const multiplier    = () => 1 + 0.25 * state.levels.mult;
const bonusActive   = () => Date.now() < bonusEndsAt;
const bonusFactor   = () => (bonusActive() ? 2 : 1);
const clickValue    = () => (1 + state.levels.power) * multiplier() * bonusFactor();
const autoValue     = () => state.levels.auto * multiplier() * bonusFactor();
const autoInterval  = () => Math.max(100, Math.round(1000 * Math.pow(0.9, state.levels.speed)));
const critChance    = () => state.levels.crit * 0.05;
const bonusDuration = () => (10 + 5 * (state.levels.bonus - 1)) * 1000;
const upgradeCost   = (key) => Math.ceil(UPGRADES[key].base * Math.pow(UPGRADES[key].growth, state.levels[key]));

// Skaitļu formatēšana: 1500 -> 1.5K
function fmt(n) {
    n = Math.floor(n);
    if (n < 10000) return n.toLocaleString("lv-LV");
    const units = ["", "K", "M", "B", "T"];
    let i = 0;
    while (n >= 1000 && i < units.length - 1) { n /= 1000; i++; }
    return n.toFixed(n < 100 ? 1 : 0) + units[i];
}

/* =========================================================
   6. PUNKTU PIEVIENOŠANA UN TRANSFORMĀCIJAS
   ========================================================= */

function addPoints(amount) {
    state.points += amount;
    state.totalEarned += amount;
    checkStage();
    updateUI();
}

function stageFor(total) {
    let idx = 0;
    STAGES.forEach((s, i) => { if (total >= s.at) idx = i; });
    return idx;
}

function applyStage(idx, announce) {
    truckWrap.className = "stage-" + idx;
    $("badge").textContent = STAGES[idx].badge;
    $("stageName").textContent = STAGES[idx].name;

    if (announce) {
        const isFinal = idx === STAGES.length - 1;
        play(isFinal ? "final" : "transform");
        showBanner(isFinal ? "🏆 Gala transformācija: " + STAGES[idx].name + "!" : "✨ Transformācija: " + STAGES[idx].name);
        truckWrap.classList.add("flash");
        setTimeout(() => truckWrap.classList.remove("flash"), 900);
    }
}

function checkStage() {
    const idx = stageFor(state.totalEarned);
    if (idx !== stageIndex) {
        const up = idx > stageIndex;
        stageIndex = idx;
        applyStage(idx, up);
    }
}

function showBanner(text) {
    const b = $("banner");
    b.textContent = text;
    b.classList.add("show");
    clearTimeout(showBanner.t);
    showBanner.t = setTimeout(() => b.classList.remove("show"), 2500);
}

/* =========================================================
   7. KLIKŠĶIS, AUTOMĀTISKIE PUNKTI, BONUSS
   ========================================================= */

function floatText(text, x, y, crit) {
    const el = document.createElement("div");
    el.className = "floater" + (crit ? " crit" : "");
    el.textContent = text;
    el.style.left = x + "px";
    el.style.top = y + "px";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 900);
}

truck.addEventListener("click", (e) => {
    let gain = Math.max(1, Math.round(clickValue()));
    const crit = Math.random() < critChance();
    if (crit) gain *= 5;

    addPoints(gain);
    play("click", crit ? 1.6 : 1);
    floatText("+" + fmt(gain), e.clientX || truck.getBoundingClientRect().left + 100, e.clientY || 200, crit);
});

function autoTick() {
    if (state.levels.auto > 0) {
        addPoints(Math.max(1, Math.round(autoValue())));
    }
}

function restartAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(autoTick, autoInterval());
}

bonusButton.addEventListener("click", () => {
    const now = Date.now();
    if (state.levels.bonus < 1 || bonusActive() || now < bonusReadyAt) return;
    bonusEndsAt = now + bonusDuration();
    bonusReadyAt = bonusEndsAt + BONUS_COOLDOWN;
    play("bonus");
    showBanner("⚡ Dubultie punkti aktivizēti!");
});

/* =========================================================
   8. UZLABOJUMI
   ========================================================= */

function buildUpgrades() {
    const list = $("upgradesList");
    list.innerHTML = "";
    for (const key in UPGRADES) {
        const u = UPGRADES[key];
        const card = document.createElement("div");
        card.className = "upgrade";
        card.id = "up-" + key;
        card.innerHTML =
            '<div class="up-icon">' + u.icon + '</div>' +
            '<div class="up-info"><b>' + u.name + ' <span class="lvl"></span></b><small>' + u.desc + '</small></div>' +
            '<button class="buy"></button>';
        card.querySelector(".buy").addEventListener("click", () => buy(key));
        list.appendChild(card);
    }
}

function buy(key) {
    const u = UPGRADES[key];
    if (state.levels[key] >= u.max) return;

    const cost = upgradeCost(key);
    if (state.points < cost) { play("deny"); return; }

    state.points -= cost;
    state.levels[key]++;
    play("upgrade");
    if (key === "speed") restartAuto();
    updateUI();
}

/* =========================================================
   9. INTERFEISA ATJAUNOŠANA
   ========================================================= */

function updateUI() {
    scoreEl.textContent = fmt(state.points);

    statsEl.textContent =
        "Klikšķis: " + fmt(clickValue()) +
        (state.levels.auto ? " · Auto: " + fmt(autoValue()) + " / " + (autoInterval() / 1000).toFixed(2) + " s" : "") +
        (state.levels.mult ? " · x" + multiplier().toFixed(2) : "");

    // Progress līdz nākamajai transformācijai
    const next = STAGES[stageIndex + 1];
    if (next) {
        const cur = STAGES[stageIndex].at;
        const pct = Math.min(100, ((state.totalEarned - cur) / (next.at - cur)) * 100);
        $("progressBar").style.width = pct + "%";
        $("progressText").textContent = fmt(state.totalEarned) + " / " + fmt(next.at);
    } else {
        $("progressBar").style.width = "100%";
        $("progressText").textContent = "Maksimālais līmenis!";
    }

    // Uzlabojumu kartītes
    for (const key in UPGRADES) {
        const u = UPGRADES[key];
        const card = $("up-" + key);
        if (!card) continue;
        const lvl = state.levels[key];
        const btn = card.querySelector(".buy");
        card.querySelector(".lvl").textContent = "(lvl " + lvl + ")";
        if (lvl >= u.max) {
            btn.textContent = "MAX";
            btn.disabled = true;
        } else {
            btn.textContent = fmt(upgradeCost(key));
            btn.disabled = false;
            btn.classList.toggle("poor", state.points < upgradeCost(key));
        }
    }
}

// Bonusa poga un taimeri (atjauno 4x sekundē)
function updateBonusUI() {
    const now = Date.now();
    document.body.classList.toggle("bonus-on", bonusActive());

    if (state.levels.bonus < 1) {
        bonusButton.disabled = true;
        bonusButton.textContent = "⚡ Bonuss (nopērc uzlabojumu)";
    } else if (bonusActive()) {
        bonusButton.disabled = true;
        bonusButton.textContent = "⚡ x2 vēl " + Math.ceil((bonusEndsAt - now) / 1000) + " s";
    } else if (now < bonusReadyAt) {
        bonusButton.disabled = true;
        bonusButton.textContent = "⏳ Gaidi " + Math.ceil((bonusReadyAt - now) / 1000) + " s";
    } else {
        bonusButton.disabled = false;
        bonusButton.textContent = "⚡ Dubultie punkti (" + bonusDuration() / 1000 + " s)";
    }
}
setInterval(updateBonusUI, 250);

function setStatus(text) {
    $("status").textContent = text;
}

/* =========================================================
   10. SAGLABĀŠANA / IELĀDE (PHP)
   ========================================================= */

function payload() {
    return JSON.stringify({ name: playerName, state: state });
}

async function saveGame() {
    if (!playerName) return;
    try {
        const res = await fetch("php/save.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: payload(),
        });
        const data = await res.json();
        setStatus(data.ok ? "Saglabāts ✔" : "Neizdevās saglabāt");
    } catch (err) {
        setStatus("Nav savienojuma ar serveri");
    }
}

// Saglabā arī tad, kad lapa tiek aizvērta
function saveOnExit() {
    if (!playerName) return;
    navigator.sendBeacon("php/save.php", new Blob([payload()], { type: "application/json" }));
}
window.addEventListener("pagehide", saveOnExit);
document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") saveOnExit();
});

async function loadGame() {
    state = newState();
    try {
        const res = await fetch("php/load.php?name=" + encodeURIComponent(playerName));
        const data = await res.json();
        if (data.ok && data.state) state = data.state;
    } catch (err) {
        setStatus("Nevar ielādēt saglabājumu");
    }
    bonusEndsAt = 0;
    bonusReadyAt = 0;
    stageIndex = stageFor(state.totalEarned);
    applyStage(stageIndex, false);
    restartAuto();
    updateUI();
}

/* =========================================================
   11. LĪDERU SARAKSTS
   ========================================================= */

async function showLeaderboard() {
    await saveGame(); // lai saraksts ietver arī pašreizējo rezultātu
    const list = $("leaderboardList");
    list.innerHTML = "<li>Ielādē...</li>";
    $("leaderboardMenu").style.display = "flex";
    try {
        const res = await fetch("php/leaderboard.php");
        const data = await res.json();
        list.innerHTML = "";
        data.top.forEach((row) => {
            const li = document.createElement("li");
            li.textContent = row.name + " — " + fmt(row.total);
            list.appendChild(li);
        });
        if (!data.top.length) list.innerHTML = "<li>Vēl nav rezultātu</li>";
    } catch (err) {
        list.innerHTML = "<li>Kļūda ielādējot</li>";
    }
}

/* =========================================================
   12. POGAS UN IESTATĪJUMI
   ========================================================= */

$("settingsButton").addEventListener("click", () => { $("settingsMenu").style.display = "flex"; });
$("closeSettings").addEventListener("click", () => { $("settingsMenu").style.display = "none"; });
$("upgradesButton").addEventListener("click", () => { $("upgradesPanel").classList.toggle("open"); });
$("closeUpgrades").addEventListener("click", () => { $("upgradesPanel").classList.remove("open"); });
$("leaderboardButton").addEventListener("click", showLeaderboard);
$("closeLeaderboard").addEventListener("click", () => { $("leaderboardMenu").style.display = "none"; });

$("volume").value = volume;
$("mute").checked = muted;
$("volume").addEventListener("input", (e) => {
    volume = parseFloat(e.target.value);
    localStorage.setItem("volume", volume);
});
$("mute").addEventListener("change", (e) => {
    muted = e.target.checked;
    localStorage.setItem("muted", muted ? "1" : "0");
});

$("resetButton").addEventListener("click", () => {
    if (!confirm("Vai tiešām atiestatīt visu progresu?")) return;
    state = newState();
    bonusEndsAt = 0;
    bonusReadyAt = 0;
    stageIndex = 0;
    applyStage(0, false);
    restartAuto();
    updateUI();
    saveGame();
    $("settingsMenu").style.display = "none";
});

$("changePlayer").addEventListener("click", async () => {
    await saveGame();
    $("settingsMenu").style.display = "none";
    $("nameInput").value = "";
    $("nameScreen").style.display = "flex";
});

/* =========================================================
   13. SĀKUMS
   ========================================================= */

async function startAs(name) {
    name = name.trim().slice(0, 20);
    if (!name) return;
    playerName = name;
    localStorage.setItem("player", name);
    $("nameScreen").style.display = "none";
    await loadGame();
}

$("startButton").addEventListener("click", () => startAs($("nameInput").value));
$("nameInput").addEventListener("keydown", (e) => { if (e.key === "Enter") startAs($("nameInput").value); });

function init() {
    buildUpgrades();
    updateUI();
    setInterval(saveGame, AUTOSAVE_MS);

    const known = window.PLAYER || localStorage.getItem("player");
    if (known) {
        startAs(known);
    } else {
        $("nameScreen").style.display = "flex";
    }
}

init();
