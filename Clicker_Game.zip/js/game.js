"use strict";

/* =========================================================
   1. KONFIGURĀCIJA
   ========================================================= */

// FLOTE: automātiski nopelna € katrā ciklā (out = € par vienu vienību)
const FLEET = {
    driver:  { name: "Šoferis",              icon: "🧑‍🔧", desc: "Brauc reisus bez tavas palīdzības", out: 1,    base: 30,      growth: 1.15 },
    trailer: { name: "Piekabe",              icon: "🔗", desc: "Vairāk kravas uz katra reisa",       out: 6,    base: 300,     growth: 1.15 },
    depot:   { name: "Depo",                 icon: "🏭", desc: "Remonts un uzpilde bez pauzēm",      out: 35,   base: 2500,    growth: 1.15 },
    route:   { name: "Starppilsētu maršruts", icon: "🛣️", desc: "Garie reisi ar labu samaksu",        out: 200,  base: 20000,   growth: 1.15 },
    port:    { name: "Ostas termināls",      icon: "⚓", desc: "Konteineri no visas pasaules",       out: 1200, base: 150000,  growth: 1.15 },
    hub:     { name: "Loģistikas centrs",    icon: "🌍", desc: "Globāls kravu tīkls",                out: 8000, base: 1200000, growth: 1.15 },
};

// UZLABOJUMI: uzlabo tavu kravas auto un uzņēmumu
const UPGRADES = {
    engine:    { name: "Jaudīgāks dzinējs", icon: "🔧", desc: "+1 € par katru klikšķi",                           base: 15,   growth: 1.45, max: 999 },
    turbo:     { name: "Turbo sistēma",     icon: "⚡", desc: "Flotes reisi notiek par 8% ātrāk",                  base: 250,  growth: 1.9,  max: 15 },
    contracts: { name: "Kravu līgumi",      icon: "📑", desc: "+25% pie visiem ieņēmumiem",                        base: 1000, growth: 2.4,  max: 12 },
    crit:      { name: "Ātrā piegāde",      icon: "🎯", desc: "+4% iespēja, ka klikšķis atnes x7 (steidzama krava)", base: 400,  growth: 1.9,  max: 10 },
    shift:     { name: "Nakts maiņa",       icon: "🌙", desc: "Atslēdz dubultus ieņēmumus (10 s, +5 s par līmeni)", base: 600,  growth: 2.0,  max: 8 },
};

// Kravas auto transformācijas (atkarībā no kopā nopelnītās naudas)
const STAGES = [
    { at: 0,          name: "Vecais darbarūķis",   badge: "🚚" },
    { at: 200,        name: "Zaļais pārvadātājs",  badge: "🌿" },
    { at: 2000,       name: "Zilais ātrgaitnieks", badge: "💨" },
    { at: 20000,      name: "Oranžais milzis",     badge: "🔶" },
    { at: 200000,     name: "Nakts braucējs",      badge: "🌙" },
    { at: 2000000,    name: "Uguns kravas auto",   badge: "🔥" },
    { at: 20000000,   name: "Varavīksnes zvērs",   badge: "🌈" },
    { at: 200000000,  name: "Kosmosa kravinieks",  badge: "🚀" },
    { at: 1000000000, name: "Zelta leģenda",       badge: "👑" },
];

const BONUS_COOLDOWN = 45000;   // ms pēc bonusa beigām
const AUTOSAVE_MS = 10000;      // automātiskā saglabāšana ik pēc 10 s

const SOUND_FILES = {
    click:     "assets/sounds/click.wav",
    upgrade:   "assets/sounds/upgrade.wav",
    bonus:     "assets/sounds/bonus.wav",
    transform: "assets/sounds/transform.wav",
    final:     "assets/sounds/final.wav",
    deny:      "assets/sounds/deny.wav",
};

/* =========================================================
   2. STĀVOKLIS
   ========================================================= */

function newState() {
    return {
        points: 0,
        totalEarned: 0,
        levels: { engine: 0, turbo: 0, contracts: 0, crit: 0, shift: 0, driver: 0, trailer: 0, depot: 0, route: 0, port: 0, hub: 0 },
    };
}

let state = newState();
let playerName = "";
let stageIndex = 0;
let bonusEndsAt = 0;
let bonusReadyAt = 0;
let autoTimer = null;

/* =========================================================
   3. DOM ELEMENTI
   ========================================================= */

const $ = (id) => document.getElementById(id);

const truck = $("truck");
const truckWrap = $("truckWrap");
const scoreEl = $("score");
const statsEl = $("stats");
const bonusButton = $("bonusButton");

/* =========================================================
   4. SKAŅA
   ========================================================= */

const sounds = {};
for (const key in SOUND_FILES) {
    sounds[key] = new Audio(SOUND_FILES[key]);
}

let volume = parseFloat(localStorage.getItem("volume") ?? "0.6");
let muted = localStorage.getItem("muted") === "1";

function play(name, rate = 1) {
    if (muted) return;
    const a = sounds[name].cloneNode(); // klons ļauj skaņai atskanēt vairākas reizes pēc kārtas
    a.volume = volume;
    a.playbackRate = rate;
    a.play().catch(() => {});
}

/* =========================================================
   5. APRĒĶINI
   ========================================================= */

const L = (k) => state.levels[k];
const multiplier    = () => 1 + 0.25 * L("contracts");
const bonusActive   = () => Date.now() < bonusEndsAt;
const bonusFactor   = () => (bonusActive() ? 2 : 1);
const autoInterval  = () => Math.max(200, Math.round(1000 * Math.pow(0.92, L("turbo"))));
const fleetPerTick  = () => Object.keys(FLEET).reduce((sum, k) => sum + L(k) * FLEET[k].out, 0);
const autoValue     = () => fleetPerTick() * multiplier() * bonusFactor();
const perSecond     = () => autoValue() * 1000 / autoInterval();
// klikšķis dod arī 3% no flotes ieņēmumiem, lai klikšķināšana paliek vērtīga visu spēli
const clickValue    = () => (1 + L("engine") + fleetPerTick() * 1000 / autoInterval() * 0.03) * multiplier() * bonusFactor();
const critChance    = () => L("crit") * 0.04;
const bonusDuration = () => (10 + 5 * (L("shift") - 1)) * 1000;
const itemDef       = (k) => FLEET[k] || UPGRADES[k];
const upgradeCost   = (k) => Math.ceil(itemDef(k).base * Math.pow(itemDef(k).growth, L(k)));

// Skaitļu formatēšana: 1500 -> 1.5K
function fmt(n) {
    n = Math.floor(n);
    if (n < 10000) return n.toLocaleString("lv-LV");
    const units = ["", "K", "M", "B", "T", "Qa"];
    let i = 0;
    while (n >= 1000 && i < units.length - 1) { n /= 1000; i++; }
    return n.toFixed(n < 100 ? 1 : 0) + units[i];
}

/* =========================================================
   6. PUNKTU PIEVIENOŠANA UN TRANSFORMĀCIJAS
   ========================================================= */

function addPoints(amount) {
    state.points += amount;
    state.totalEarned += amount;
    checkStage();
    updateUI();
}

function stageFor(total) {
    let idx = 0;
    STAGES.forEach((s, i) => { if (total >= s.at) idx = i; });
    return idx;
}

function applyStage(idx, announce) {
    truckWrap.className = "stage-" + idx;
    $("badge").textContent = STAGES[idx].badge;
    $("stageName").textContent = STAGES[idx].name;

    if (announce) {
        const isFinal = idx === STAGES.length - 1;
        play(isFinal ? "final" : "transform");
        showBanner(isFinal ? "🏆 Gala transformācija: " + STAGES[idx].name + "!" : "✨ Transformācija: " + STAGES[idx].name);
        truckWrap.classList.add("flash");
        setTimeout(() => truckWrap.classList.remove("flash"), 900);
    }
}

function checkStage() {
    const idx = stageFor(state.totalEarned);
    if (idx !== stageIndex) {
        const up = idx > stageIndex;
        stageIndex = idx;
        applyStage(idx, up);
    }
}

function showBanner(text) {
    const b = $("banner");
    b.textContent = text;
    b.classList.add("show");
    clearTimeout(showBanner.t);
    showBanner.t = setTimeout(() => b.classList.remove("show"), 2500);
}

/* =========================================================
   7. KLIKŠĶIS, AUTOMĀTISKIE PUNKTI, BONUSS
   ========================================================= */

function floatText(text, x, y, crit) {
    const el = document.createElement("div");
    el.className = "floater" + (crit ? " crit" : "");
    el.textContent = text;
    el.style.left = x + "px";
    el.style.top = y + "px";
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 900);
}

truck.addEventListener("click", (e) => {
    let gain = Math.max(1, Math.round(clickValue()));
    const crit = Math.random() < critChance();
    if (crit) gain *= 7;

    addPoints(gain);
    play("click", crit ? 1.6 : 1);
    floatText("+" + fmt(gain), e.clientX || truck.getBoundingClientRect().left + 100, e.clientY || 200, crit);
});

function autoTick() {
    if (fleetPerTick() > 0) {
        addPoints(Math.max(1, Math.round(autoValue())));
    }
}

function restartAuto() {
    clearInterval(autoTimer);
    autoTimer = setInterval(autoTick, autoInterval());
}

bonusButton.addEventListener("click", () => {
    const now = Date.now();
    if (L("shift") < 1 || bonusActive() || now < bonusReadyAt) return;
    bonusEndsAt = now + bonusDuration();
    bonusReadyAt = bonusEndsAt + BONUS_COOLDOWN;
    play("bonus");
    showBanner("🌙 Nakts maiņa: dubulti ieņēmumi!");
});

/* =========================================================
   8. UZLABOJUMI
   ========================================================= */

function buildCards(listId, defs) {
    const list = $(listId);
    list.innerHTML = "";
    for (const key in defs) {
        const u = defs[key];
        const card = document.createElement("div");
        card.className = "upgrade";
        card.id = "up-" + key;
        card.innerHTML =
            '<div class="up-icon">' + u.icon + '</div>' +
            '<div class="up-info"><b>' + u.name + ' <span class="lvl"></span></b><small>' + u.desc + '</small><small class="extra"></small></div>' +
            '<button class="buy"></button>';
        card.querySelector(".buy").addEventListener("click", () => buy(key));
        list.appendChild(card);
    }
}

function buildUpgrades() {
    buildCards("fleetList", FLEET);
    buildCards("upgradesList", UPGRADES);
}

function buy(key) {
    const u = itemDef(key);
    if (u.max && L(key) >= u.max) return;

    const cost = upgradeCost(key);
    if (state.points < cost) { play("deny"); return; }

    state.points -= cost;
    state.levels[key]++;
    play("upgrade");
    if (key === "turbo") restartAuto();
    updateUI();
}

/* ---------- Nejaušs bonusa krātiņš uz ceļa (klikšķini ātri!) ---------- */

function scheduleCrate() {
    setTimeout(spawnCrate, 20000 + Math.random() * 25000);
}

function spawnCrate() {
    const stage = $("stage");
    const crate = document.createElement("button");
    crate.className = "crate";
    crate.textContent = "📦";
    crate.style.left = (10 + Math.random() * 75) + "%";
    crate.style.top = (10 + Math.random() * 65) + "%";
    crate.addEventListener("click", (e) => {
        const gain = Math.max(100, Math.round(Math.max(perSecond() * 30, clickValue() * 30)));
        addPoints(gain);
        play("bonus");
        floatText("📦 +" + fmt(gain), e.clientX, e.clientY, true);
        showBanner("📦 Steidzama krava piegādāta!");
        crate.remove();
    });
    stage.appendChild(crate);
    setTimeout(() => crate.remove(), 9000);
    scheduleCrate();
}

/* =========================================================
   9. INTERFEISA ATJAUNOŠANA
   ========================================================= */

function updateUI() {
    scoreEl.textContent = fmt(state.points);

    statsEl.textContent =
        "Klikšķis: €" + fmt(clickValue()) +
        (fleetPerTick() ? " · Flote: €" + fmt(perSecond()) + "/s" : "") +
        (L("contracts") ? " · x" + multiplier().toFixed(2) : "");

    const next = STAGES[stageIndex + 1];
    if (next) {
        const cur = STAGES[stageIndex].at;
        const pct = Math.min(100, ((state.totalEarned - cur) / (next.at - cur)) * 100);
        $("progressBar").style.width = pct + "%";
        $("progressText").textContent = fmt(state.totalEarned) + " / " + fmt(next.at);
    } else {
        $("progressBar").style.width = "100%";
        $("progressText").textContent = "Maksimālais līmenis!";
    }

    for (const key in Object.assign({}, FLEET, UPGRADES)) {
        const u = itemDef(key);
        const card = $("up-" + key);
        if (!card) continue;
        const btn = card.querySelector(".buy");
        card.querySelector(".lvl").textContent = FLEET[key] ? "× " + L(key) : "(lvl " + L(key) + ")";
        card.querySelector(".extra").textContent = FLEET[key] ? "Nopelna €" + fmt(L(key) * u.out * multiplier()) + " katrā reisā" : "";
        if (u.max && L(key) >= u.max) {
            btn.textContent = "MAX";
            btn.disabled = true;
        } else {
            btn.textContent = "€" + fmt(upgradeCost(key));
            btn.disabled = false;
            card.classList.toggle("poor", state.points < upgradeCost(key));
        }
    }
}

// Bonusa poga un taimeri (atjauno 4x sekundē)
function updateBonusUI() {
    const now = Date.now();
    document.body.classList.toggle("bonus-on", bonusActive());

    if (L("shift") < 1) {
        bonusButton.disabled = true;
        bonusButton.textContent = "🌙 Nakts maiņa (uzlabojums)";
    } else if (bonusActive()) {
        bonusButton.disabled = true;
        bonusButton.textContent = "🌙 x2 vēl " + Math.ceil((bonusEndsAt - now) / 1000) + " s";
    } else if (now < bonusReadyAt) {
        bonusButton.disabled = true;
        bonusButton.textContent = "⏳ Gaidi " + Math.ceil((bonusReadyAt - now) / 1000) + " s";
    } else {
        bonusButton.disabled = false;
        bonusButton.textContent = "🌙 Nakts maiņa x2 (" + bonusDuration() / 1000 + " s)";
    }
}
setInterval(updateBonusUI, 250);

function setStatus(text) {
    $("status").textContent = text;
}

/* =========================================================
   10. SAGLABĀŠANA / IELĀDE (PHP)
   ========================================================= */

function payload() {
    return JSON.stringify({ name: playerName, state: state });
}

async function saveGame() {
    if (!playerName) return;
    try {
        const res = await fetch("php/save.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: payload(),
        });
        const data = await res.json();
        setStatus(data.ok ? "Saglabāts ✔" : "Neizdevās saglabāt");
    } catch (err) {
        setStatus("Nav savienojuma ar serveri");
    }
}

// Saglabā arī tad, kad lapa tiek aizvērta
function saveOnExit() {
    if (!playerName) return;
    navigator.sendBeacon("php/save.php", new Blob([payload()], { type: "application/json" }));
}
window.addEventListener("pagehide", saveOnExit);
document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "hidden") saveOnExit();
});

async function loadGame() {
    state = newState();
    try {
        const res = await fetch("php/load.php?name=" + encodeURIComponent(playerName));
        const data = await res.json();
        if (data.ok && data.state) state = data.state;
    } catch (err) {
        setStatus("Nevar ielādēt saglabājumu");
    }
    bonusEndsAt = 0;
    bonusReadyAt = 0;
    stageIndex = stageFor(state.totalEarned);
    applyStage(stageIndex, false);
    restartAuto();
    updateUI();
}

/* =========================================================
   11. LĪDERU SARAKSTS
   ========================================================= */

async function showLeaderboard() {
    await saveGame(); // lai saraksts ietver arī pašreizējo rezultātu
    const list = $("leaderboardList");
    list.innerHTML = "<li>Ielādē...</li>";
    $("leaderboardMenu").style.display = "flex";
    try {
        const res = await fetch("php/leaderboard.php");
        const data = await res.json();
        list.innerHTML = "";
        data.top.forEach((row) => {
            const li = document.createElement("li");
            li.textContent = row.name + " — " + fmt(row.total);
            list.appendChild(li);
        });
        if (!data.top.length) list.innerHTML = "<li>Vēl nav rezultātu</li>";
    } catch (err) {
        list.innerHTML = "<li>Kļūda ielādējot</li>";
    }
}

/* =========================================================
   12. POGAS UN IESTATĪJUMI
   ========================================================= */

$("settingsButton").addEventListener("click", () => { $("settingsMenu").style.display = "flex"; });
$("closeSettings").addEventListener("click", () => { $("settingsMenu").style.display = "none"; });
$("leaderboardButton").addEventListener("click", showLeaderboard);
$("closeLeaderboard").addEventListener("click", () => { $("leaderboardMenu").style.display = "none"; });

$("volume").value = volume;
$("mute").checked = muted;
$("volume").addEventListener("input", (e) => {
    volume = parseFloat(e.target.value);
    localStorage.setItem("volume", volume);
});
$("mute").addEventListener("change", (e) => {
    muted = e.target.checked;
    localStorage.setItem("muted", muted ? "1" : "0");
});

$("resetButton").addEventListener("click", () => {
    if (!confirm("Vai tiešām atiestatīt visu progresu?")) return;
    state = newState();
    bonusEndsAt = 0;
    bonusReadyAt = 0;
    stageIndex = 0;
    applyStage(0, false);
    restartAuto();
    updateUI();
    saveGame();
    $("settingsMenu").style.display = "none";
});

$("changePlayer").addEventListener("click", async () => {
    await saveGame();
    $("settingsMenu").style.display = "none";
    $("nameInput").value = "";
    $("nameScreen").style.display = "flex";
});

/* =========================================================
   13. SĀKUMS
   ========================================================= */

async function startAs(name) {
    name = name.trim().slice(0, 20);
    if (!name) return;
    playerName = name;
    localStorage.setItem("player", name);
    $("nameScreen").style.display = "none";
    await loadGame();
}

$("startButton").addEventListener("click", () => startAs($("nameInput").value));
$("nameInput").addEventListener("keydown", (e) => { if (e.key === "Enter") startAs($("nameInput").value); });

function init() {
    buildUpgrades();
    updateUI();
    setInterval(saveGame, AUTOSAVE_MS);
    scheduleCrate();

    const known = window.PLAYER || localStorage.getItem("player");
    if (known) {
        startAs(known);
    } else {
        $("nameScreen").style.display = "flex";
    }
}

init();
