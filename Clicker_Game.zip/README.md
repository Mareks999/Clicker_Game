# Truck Clicker

Kravas auto klikšķināšanas spēle (HTML, CSS, JavaScript, PHP).

Palaišana: `php -S localhost:8000` projekta mapē, tad atvērt http://localhost:8000/index.php
(vai ievietot mapi XAMPP `htdocs`). Mapei `data/saves` jābūt rakstāmai.
